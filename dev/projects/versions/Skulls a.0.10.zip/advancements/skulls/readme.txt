Copyright rster2002, all rights reserved.

This was made in collaboration with Luuk_T and Pyrollenium.